clear
time ./wolf3d
